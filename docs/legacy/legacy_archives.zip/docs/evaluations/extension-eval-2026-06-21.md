# Extension Eval — 2026-06-21

**Overall: 300/400 (75.0%) — PASS**

- Profile: `cloud`
- Mock mode: `True`
- Vision available: `True`

## Per-Track Results

| Track | Score | % | Status |
|-------|-------|---|--------|
| Track 3 — Interactive DOM | 300/400 | 75.0% | ✅ Pass |

## Turn Details

### [EX3.1] Click Element — ✅ 75/100
- Tools: `['get_active_browser_context', 'active_browser_action']`
- Route: `complex-cloud`
- Duration: 8.7s
- Breakdown:
  - +40: Tool 'active_browser_action' called correctly
  - +20: Response non-empty (41 chars ≥ 10)
  - +10: No DSML leak
  - +5: Clean response

### [EX3.2] Type into Field — ✅ 75/100
- Tools: `['get_active_browser_context', 'active_browser_action', 'get_active_browser_screenshot']`
- Route: `complex-cloud`
- Duration: 17.7s
- Breakdown:
  - +40: Tool 'active_browser_action' called correctly
  - +20: Response non-empty (196 chars ≥ 10)
  - +10: No DSML leak
  - +5: Clean response

### [EX3.3] Scroll Page — ✅ 75/100
- Tools: `['active_browser_action']`
- Route: `complex-cloud`
- Duration: 7.7s
- Breakdown:
  - +40: Tool 'active_browser_action' called correctly
  - +20: Response non-empty (152 chars ≥ 8)
  - +10: No DSML leak
  - +5: Clean response

### [EX3.4] Hover Element — ✅ 75/100
- Tools: `['get_active_browser_context', 'get_active_browser_screenshot', 'active_browser_action']`
- Route: `complex-cloud`
- Duration: 21.8s
- Breakdown:
  - +40: Tool 'active_browser_action' called correctly
  - +20: Response non-empty (408 chars ≥ 8)
  - +10: No DSML leak
  - +5: Clean response
